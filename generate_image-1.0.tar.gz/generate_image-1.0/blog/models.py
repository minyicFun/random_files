from django.db import models


class Author(models.Model):
    # 自己指定对应表名，不指定则默认使用路径名，不推荐
    class Meta:
        db_table = 'author'

    class Gender(models.IntegerChoices):
        MAN = 1, 'Male'
        FEMALE = 2, 'Female'
        OTHER = 3, 'Others'

    id = models.AutoField(primary_key=True, verbose_name='authorID')
    name = models.CharField(max_length=128, default="Anonymous")
    email = models.CharField(max_length=128, null=True)
    age = models.IntegerField(null=True)
    gender = models.SmallIntegerField(choices=Gender.choices, default=3)  # default 只是Django里面的，不会在建表的时候定义
    description = models.CharField(max_length=50, default="This user is shy.")
    register_time = models.DateTimeField(auto_created=True, auto_now=True)

    # 额外的加工，下面的部分纯粹就是为了自己调试使用的
    # @property
    # def name(self):
    #     return "{} {}".format(self.id, self.name)

    # 注意这里可以通过 self 访问属性，这部分工作是 model.Model 帮忙封装的
    def __repr__(self):
        return "<Author {}>".format(self.name)

    __str__ = __repr__


class Blog(models.Model):
    class Meta:
        db_table = 'blog'

    id = models.AutoField(primary_key=True, verbose_name='blogID')
    content = models.TextField(null=True)
    # django会给外键字段自动加后缀_id，如果不需要加这个后缀，用db_column指定
    # 需要指定 db_column，因为 author_id 会指向 Author 实例，而查询 db 的时候，会查找 author_id + _id，
    # 因此需要告诉 Django 去找哪一个 column
    author_id = models.ForeignKey(Author, on_delete=models.CASCADE, db_column='author_id', related_name='blogs')

    # 注意这里可以通过 self 访问属性，这部分工作是 model.Model 帮忙封装的
    def __repr__(self):
        return "<Blog {} {}>".format(self.id, self.author_id)

    __str__ = __repr__


class Comment(models.Model):
    class Meta:
        db_table = 'comment'

    id = models.AutoField(primary_key=True, verbose_name='commentID')
    content = models.TextField()
    publish_date = models.DateTimeField()
    edit_date = models.DateTimeField()
    author_id = models.ForeignKey(Author, db_column="author_id", on_delete=models.CASCADE, related_name="comments")
    blog_id = models.ForeignKey(Blog, db_column='blog_id', on_delete=models.CASCADE, related_name="comment")

    # 注意这里可以通过 self 访问属性，这部分工作是 model.Model 帮忙封装的
    def __repr__(self):
        return "<Comment {} {}>".format(self.id, self.content)

    __str__ = __repr__
