from rest_framework import serializers
from blog.models import Author, Blog, Comment


# class AuthorSerializer(serializers.Serializer):
#     id = serializers.IntegerField(label='AuthorID', read_only=True)
#     name = serializers.CharField()
#     email = serializers.CharField()
#     age = serializers.IntegerField()
#     gender = serializers.ChoiceField(Author.Gender.choices)
#     description = serializers.CharField()
#     register_time = serializers.DateTimeField()
#
#     def create(self, validated_data):
#         return Author.objects.create(**validated_data)
#
#     def update(self, instance:Author, validated_data):
#         instance.name = validated_data.get('name', instance.name)
#         instance.email = validated_data.get('email', instance.email)
#         instance.age = validated_data.get('age', instance.age)
#         instance.gender = validated_data.get('gender', instance.gender)
#         instance.description = validated_data.get('description', instance.description)
#         instance.save()
#         return instance

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'

class BlogSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blog
        fields = '__all__'

    comments = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

class AuthorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Author # 参照的 model
        fields = '__all__' # 那些字段

    # 额外添加的字段，建议添加 read_only 属性，一般不建议在这里写入和修改
    # blogs = serializers.PrimaryKeyRelatedField(many=True, queryset=Blog.objects.all()) # 显示 pk, 可以修改
    # blogs = serializers.PrimaryKeyRelatedField(many=True, read_only=True) # 显示 pk
    # blogs = serializers.StringRelatedField(many=True, read_only=True) # 显示 repr， 默认为 read_only
    blogs = BlogSerializer(many=True, read_only=True)

    comments = serializers.PrimaryKeyRelatedField(many=True, read_only=True)