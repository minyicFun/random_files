import datetime

from django.shortcuts import render
from django.http import HttpResponse, HttpRequest, JsonResponse

# Create your views here.
from django.views.decorators.http import require_http_methods
from rest_framework.views import APIView, Response, Request
from blog.models import Author, Blog, Comment
from blog.serializers import AuthorSerializer, BlogSerializer, CommentSerializer

# 通用视图
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import (
    ListModelMixin,  # list -> get
    CreateModelMixin,  # create -> post
    RetrieveModelMixin,  # retrieve -> get
    UpdateModelMixin,  # update -> put
    DestroyModelMixin  # destroy -> delete
)

# concrete 视图
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView

# 视图集
from rest_framework.viewsets import ModelViewSet


def welcome(request: HttpRequest):
    return HttpResponse('<html><body><h1> Welcome </h1></body></html>')


@require_http_methods(["GET"])
def current_datetime(request: HttpRequest):
    now = datetime.datetime.now()
    html = f'<html><body>{now}</body></html>'

    response = HttpResponse(html)
    # response.headers['Access-Control-Allow-Origin'] = 'http://127.0.0.1:5173'
    # response.headers['Access-Control-Allow-Origin'] = '*'
    # response.headers['Access-Control-Allow-Headers'] = 'content-type'
    return response


# @require_http_methods(["POST"])
def generate_image(request: HttpRequest):
    print(request.body)
    return JsonResponse({"urls":["1","2","3"]}, status=200)


# class AuthorsView(APIView):
#     def get(self, request):
#         authors = Author.objects.all()
#         return Response(AuthorSerializer(instance=authors, many=True).data)
#
#     def post(self, request):
#         author_serializer = AuthorSerializer(data=request.data)  # 假设传入的已经是 json
#         valid = author_serializer.is_valid(raise_exception=False)  # 可以改为 raise_exception=True
#         if valid:
#             author_serializer.save()
#             return Response(author_serializer.data)
#         else:
#             # 如果 raise_exception=True，那么这行就没有用，因为 exception 会给 rest_framework 的 EXCEPTION_HANDLER 给捕获了，不会 return
#             return HttpResponse("Request not valid")
#
#
# class AuthorView(APIView):
#     def get(self, request):
#         obj = Author.objects.get(pk=request.data.get("id"))
#         return Response(AuthorSerializer(instance=obj).data)
#
#     # 先查后改
#     def put(self, request):
#         obj = Author.objects.get(pk=request.data.get("id"))
#         serializer = AuthorSerializer(instance=obj, data=request.data)
#         valid = serializer.is_valid(raise_exception=True)
#         if valid:
#             serializer.save()
#             return Response(serializer.data)
#
#     def delete(self, request):
#         obj = Author.objects.get(pk=request.data.get("id"))
#         obj.delete()
#         return Response(status=204)


# class AuthorsView(ListModelMixin, CreateModelMixin, GenericAPIView):
#     queryset = Author.objects.all()
#     serializer_class = AuthorSerializer
#
#     get = ListModelMixin.list
#     post = CreateModelMixin.create
#
#
# class AuthorView(RetrieveModelMixin, UpdateModelMixin, DestroyModelMixin, GenericAPIView):
#     queryset = Author.objects.all()
#     serializer_class = AuthorSerializer
#     lookup_field = 'pk'
#
#     get = RetrieveModelMixin.retrieve
#     put = UpdateModelMixin.update
#     patch = UpdateModelMixin.partial_update
#     delete = DestroyModelMixin.destroy


# class AuthorsView(ListCreateAPIView):
#     queryset = Author.objects.all()
#     serializer_class = AuthorSerializer
#
#
#
# class AuthorView(RetrieveUpdateDestroyAPIView):
#     queryset = Author.objects.all()
#     serializer_class = AuthorSerializer
#     lookup_url_kwarg = 'id'


class AuthorViewSet(ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer
    # 有需要可以自定义 pagination 类
    # pagination_class = ...
