from django.urls import path
from rest_framework.routers import SimpleRouter

# router = SimpleRouter()
# router.register('get_author', AuthorViewSet)  # 这里不需要加 /，会默认添加一个

from .views import *

urlpatterns = [
                  path('', generate_img),
    path('test/', check_post)
              ]
