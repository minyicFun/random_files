import json

import openai
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.csrf import csrf_exempt, csrf_protect, ensure_csrf_cookie
from django.views.decorators.http import require_http_methods

OPENAI_API_KEY = "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"
# openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

@ensure_csrf_cookie
def check_post(request):
    return JsonResponse({"msg":"test post"})


# Create your views here.
# @csrf_exempt
# @ensure_csrf_cookie
def generate_img(request):
    if request.method == "GET":
        print('you are in get')
        return JsonResponse({}, status=200)

    print("you have reached post action")
    prompt = json.loads(request.body.decode("utf-8"))["prompt"]

    open_ai_response = openai.Image.create(
        # prompt="Beautiful anime girl is swimming",
        prompt = prompt,
        n=4,
        size="1024x1024"
    )
    # image_url = response['data'][0]['url']
    # image_url = response['data']
    # print(image_url)
    # object_methods = [method_name for method_name in dir(image_url)
    #                   if callable(getattr(image_url, method_name))]
    # ['__add__', '__class__', '__class_getitem__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__eq__',
    #  '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__iadd__', '__imul__', '__init__',
    #  '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__',
    #  '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__',
    #  '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse',
    #  'sort']

    urls = {'urls': [jsonObj['url'] for jsonObj in open_ai_response['data']]}

    response = JsonResponse(urls, status=200)
    return response
