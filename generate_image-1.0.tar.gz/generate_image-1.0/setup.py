import setuptools

setuptools.setup(
    name="generate_image",
    version="1.0",
    author="minyi",
    author_email="minyic.22@gmail.com   ",
    description="test simple web app devt",
    url="",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    # package_dir={"": "."},
    packages=setuptools.find_packages(),  # 找当前路径下的包
    python_requires=">=3.8",  # python版本要求
    data_files=[('', ['requirements'])],  # data_files=['requirements']
    py_modules=['manage']  # 不需要扩展名.py, 为了便于测试，我们同时打包 manage.py
)
